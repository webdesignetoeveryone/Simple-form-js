function setDate(){
		document.getElementById('date').innerHTML=Date();
		}
function checkpass() {
	var password1 = document.getElementById("pass1");
	var password2 = document.getElementById("pass2");
	if ( password1.value != password2.value) {
		alert("The passwords much match!");
		return false;
	}
}

function managerFunction() {
	if (document.getElementById("yesManager").checked){
		document.getElementById("bibivibe").style.display = "inline";
		document.getElementById("timetocall").setAttribute("required",true);
	}
	else {
		document.getElementById("timetocall").removeAttribute("required",true);
		document.getElementById("bibivibe").style.display = "none";
	}
}